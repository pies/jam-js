<?php
/**
 * Name
 * --------------------------------------------------------------------------
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @package Package
 * @version $Revision: $
 * @license Public Domain (see system/licence.txt)
*/

define ('DEBUG', true);
define ('DIR_ROOT', dirname(__FILE__));

require 'system/libraries/developer/output.php';
require 'system/libraries/widgets/programatic-html-generator.php';
require 'system/libraries/extensions/enum.php';

//require 'system/libraries/extensions/str.php';
//require 'system/libraries/widgets/color-handling.php';
//require 'system/libraries/developer/better_printr-TDO.php';

/**
 * Formats and simplifies the call stack backtrace log
 *
 * @param  array $backtrace The call stack to simplify
 * @return array            Formatted and simplified backtrace log
 */
function format_trace($trace) {
	$output = array();
	foreach ($trace as $step){
		if (empty($step['file'])) continue;

		$class = str_replace(' ', '_', ucwords(str_replace('_', ' ', isset($step['class'])? $step['class']: '')));
		$type  = isset($step['type'])? $step['type']: '';
		$funct = isset($step['function'])? $step['function']: '';
		$file  = substr(str_replace(DIR_ROOT, '', $step['file']), 1);

		$output[] = array(
			'name'  => $class? $class.$type.$funct.'()': $funct.'()',
			'place' => $file.':'.$step['line'],
			'file'  => $file,
			'line'  => $step['line'],
			'class' => $class,
			'type'  => $type,
			'funct' => $funct
		);
	}
	return $output;
}	

function ul_tree($items, $parent=0, $parent_field='parent'){
	$OUT  = '';
	foreach ($items as $item) {
		if ($item[$parent_field] == $parent) {
			$lft = $item['lft'];
			$rgt = $item['rgt'];
			$kids = ($rgt-$lft-1)/2;
			$value = "{$item['id']}) $lft .. $rgt".($kids?" [$kids]":'');
			$del = $item['type']==999;
			$OUT .= "<li>".($del?'<small style="color:#888">':'').$value.ul_tree($items, $item['id'], $parent_field).($del?'</small>':'')."</li>";
		}
	}
	return $OUT? "<ul>$OUT</ul>": $OUT;
}

$conn = mysql_connect('localhost:3833', 'www', 'www');mysql_select_db('irh', $conn);
$result = mysql_query("SELECT * FROM article_tree WHERE type <> 999 ORDER BY lft ASC", $conn);
$data = array();
while ($row = mysql_fetch_assoc($result)) {
	$data[] = $row;
}

print count($data);
print ul_tree($data);

?>