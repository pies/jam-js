<?

/** 
 * Facilitates an object-oriented way of working with strings.
 * 
 * Uses the {@link Enum} class.
 * 
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @license Public Domain (see system/licence.txt)
 *
 * @package Extensions
 * @subpackage Strings
 * @version $Revision: 13 $
*/
class Str {
	
	private $value = '';
	
	function __construct($args=array()) {
		$this->value = join($args);		
	}
	
	function __call ($name, $params=array()) {
		if ('get'==$name) return $this->value;
		if (function_exists($name)) {
			return call_user_func_array($name, $params);
		}
		else {
			throw new Exception('Method not found: '.$name);
		}
	}

	function explode ($by='.') {
		return explode($by, $this->value);
	}

	function match ($regexp) {
		return preg_match_all($regexp, $this->value, $results)? array_shift($results): array();
	}
	
	/**
	 * Returns a camelized string, ie. under_scored becomes UnderScored.
	 *
	 * @test str('under_scored')->camelize()->get() == 'UnderScored'
	 * @test str('CameLized')->camelize()->get() == 'CameLized'
	 * @return string
	 */
	function camelize () {
		return str(join(array_map('ucfirst', $this->explode('_'))));
	}

	/**
	 * Returns an underscored sentence, ie. CameLizedName becomes came_lized_name.
	 *
	 * @return string
	 */
	function underscore () {
		$OUT = enum();
		foreach ($this->explode('/') as $part) {
			$OUT[] = str($part)->ucfirst()->match('/[A-Z][a-z]+/')->join('_');
		}
		return strtolower($OUT->join('/'));
	}

}

/** 
 * Creates a new Str object in flight from a string or a list of arguments
 *
 * @return Enum
 */
function str () {
	$args = func_get_args();
	return new Str($args);
}


/** 
 * Returns a sprintf() function call with custom embedded pattern.
 * 
 * @param string $pattern
 * @return callback
 */
function formatter ($pattern) {
	$src = '
if (is_string($data)) $data = array($data); else array_unshift($data, \''.$pattern.'\');
return call_user_func_array("sprintf", $data);';
	return create_function('$data', $src);
}


?>