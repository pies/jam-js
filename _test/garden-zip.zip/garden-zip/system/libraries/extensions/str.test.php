<?php
/**
 * Name
 * --------------------------------------------------------------------------
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @package Package
 * @version $Revision: $
 * @license Public Domain (see system/licence.txt)
*/

include('str.php');
include('enum.php');

assert_options(ASSERT_ACTIVE, 1);
assert_options(ASSERT_WARNING, 0);
assert_options(ASSERT_BAIL, false);
assert_options(ASSERT_CALLBACK, 'failed');

class DocComment {

	private $doc;
	
	function __construct($doc) {
		$this->doc = $this->export($doc);
	}

	function export($doc) {
		$OUT = array();
		foreach (explode("\n", $doc) as $line) {
			$line = trim($line);
			$pos = strpos($line, '* ');
			if (false!==$pos) $line = substr($line, $pos+2);
			$line = trim($line);
			if (in_array($line, array('*','/**','/*','*/'))) $line = "";
			$OUT[] = $line;
		}
		$OUT = str_replace("\n@", "\n\n@", join("\n", $OUT));
		$lines = array_filter( array_map( 'trim', explode("\n\n", $OUT)	) );
		$OUT = array();
		
		foreach ($lines as $line) {
			if (preg_match('/^@([a-z0-9\-]+)(.*)$/', $line, $match)) 
				$OUT[$match[1]][] = trim($match[2]);
			else 
				$OUT['doc'][] = $line;
		}
		
		return $OUT;
	}
	
	function __toString(){
		return join("\n\n", $this->doc);
	}
	
	function getDocs() {
		return isset($this->doc['doc'])?
			enum($this->doc['doc'])->format('<p>%s</p>')->join("\n"):
			'';
	}
	
	function getAll() {
		return $this->doc;
	}

	function getTests() {
		return isset($this->doc['test'])? $this->doc['test']: array();
	}
	
}




foreach (get_class_methods('Str') as $method) {
	$refl = new ReflectionMethod('Str', $method);
	$refl = new ReflectionDocComment($refl->getDocComment());
	$html = $refl->getDocs();
	print($html);
	$tests = $refl->getTests();
//continue;
//	if (!is_array(@$docs['test'])) continue;
	foreach ($tests as $test) {
		print "<pre>$test</pre>\n";
		assert($test);
//		
//		try { assert($test); } catch (Exception $E) { print_r($E); };
	}
}
//	print_r();



?>