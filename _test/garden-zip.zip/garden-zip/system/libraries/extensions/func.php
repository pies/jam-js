<?
/** 
 * Function and execution helpers.
 * 
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @license Public Domain (see system/licence.txt)
 *
 * @package Extensions
 * @subpackage Functions
 * @version $Revision: 13 $
 */

/**
 * Simplifies the syntax for call_user_func_array.
 * Additionaly it accepts call($object, 'method_name', $arguments))
 *
 * @param mixed $callback
 * @param mixed $args
 * @param array $extra
 */
function call ($callback, $args=array(), $extra=array()) {
	/** If used an object and a method name as args re-assign variables accordingly */
	if (is_string($args)) {
		$callback = array($callback, $args);
		$args = $extra;
	}
	return call_user_func_array($callback, $args);
}

/**
 * Exports specified class methods as functions in the global namespace.
 *
 * @param string $class Class from which the export is made.
 * @param array $funcs List of methods to export.
 */
function export ($class, $funcs=array()) {
	$php = '';
	foreach ($funcs as $func=>$alias) {
		if (!is_string($class)) $class = get_class($class);
		if (!is_string($func)) $func = $alias;
		if (!function_exists($alias)) {
			$php .=
				 "function {$alias}(){ \n"
				."print '$alias';"
				."\t\$args=func_get_args();\n"
				."\treturn Lang::call('$class', '$func', \$args);\n"
				."}\n";
		}
	}

	if ($php) eval($php);
}

?>