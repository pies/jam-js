<?php
/**
 * Name
 * --------------------------------------------------------------------------
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @package Package
 * @version $Revision: $
 * @license Public Domain (see system/licence.txt)
*/
class DocComment {

	private $doc;
	
	function __construct($doc) {
		$this->doc = $this->export($doc);
	}

	function export($doc) {
		$OUT = array();
		foreach (explode("\n", $doc) as $line) {
			$line = trim($line);
			$pos = strpos($line, '* ');
			if (false!==$pos) $line = substr($line, $pos+2);
			$line = trim($line);
			if (in_array($line, array('*','/**','/*','*/'))) $line = "";
			$OUT[] = $line;
		}
		$OUT = str_replace("\n@", "\n\n@", join("\n", $OUT));
		$lines = array_filter( array_map( 'trim', explode("\n\n", $OUT)	) );
		$OUT = array();
		
		foreach ($lines as $line) {
			if (preg_match('/^@([a-z0-9\-]+)(.*)$/', $line, $match)) 
				$OUT[$match[1]][] = trim($match[2]);
			else 
				$OUT['doc'][] = $line;
		}
		
		return $OUT;
	}
	
	function __toString(){
		return join("\n\n", $this->doc);
	}
	
	function getDocs() {
		$doc = $this->doc;
		$help = '';
		if (isset($this->doc['doc'])) {
			$help = enum($this->doc['doc'])->format('<p>%s</p>')->join("\n");
		}
		return $help;
	}
	
	function getAll() {
		return $this->doc;
	}

	function getTests() {
		return isset($this->doc['test'])? $this->doc['test']: array();
	}
	
}

?>