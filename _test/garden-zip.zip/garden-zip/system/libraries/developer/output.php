<?php
/** 
 * Debugging output
 * 
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @license Public Domain (see system/licence.txt)
 *
 * @package Developer
 * @subpackage Output
 * @version $Revision: $
*/

/**
 * Creates a generic (formatted) system message output box.
 *
 * @param string $title Message title
 * @param mixed $contents Message contents
 * @param array $trace Execution stack backtrace
 * @return string HTML
 */
function system_message ($title, $contents, $trace) {
	$OUT = '';
	if (!defined('DEBUG_SETTINGS_IN_PAGE')) {
		define('DEBUG_SETTINGS_IN_PAGE', true);
		$OUT .= <<<HTML
<style type="text/css">
._SYSTEM_BUTTON_      { position:absolute; top:5px; right:5px; background-color:#FFF; border:1px solid #D86; padding:2px 4px; text-decoration:none; font-family:Calibri,sans-serif; font-size:12px; font-weight:bold; color:#F75; }
._SYSTEM_BUTTON_ SPAN { color:#000; }
._SYSTEM_             { font-family:Calibri,Arial,sans-serif; border:1px solid #D86; padding:0; margin:.5em 0; }
._SYSTEM_ H1          { font-size:17px; margin:0; color:#F75; background-color:#EE9; padding:4px 7px; }
._SYSTEM_ A           { text-decoration:none; margin:2px 2px 0 0; font-size:19px; float:right; font-weight:bold; padding:0 8px; color:#996; }
._SYSTEM_ A:HOVER     { color:#442; }
._SYSTEM_ H1 SMALL    { font-size:15px; color: #777; }
._SYSTEM_ H1 SMALL B  { color: #000; }
._SYSTEM_ UL          { font-size:1em; padding:0; margin:5px 5px 0 0; list-style:none; }
._SYSTEM_ PRE         { background-color:#FFC; font-family:Consolas,Courier,monospace; font-size:12px; margin:0 0 5px 0; padding:4px 8px; }
._SYSTEM_ PRE EM      { color:#999; }
._SYSTEM_ .Trace      { font-size:1em; margin:0; background-color:#EE9; padding:4px 7px; }
._SYSTEM_ .Trace UL   { display:inline; }
._SYSTEM_ .Trace LI   { float:left; display:inline; }
</style>
<script type="text/javascript">
var __ = {
ID:   function(id){ return typeof(id)=='string'? document.getElementById(id): id; },
RM:   function(id){ var N = __.ID(id); N.parentNode.removeChild(N); },
TAG:  function(tag, ctx){ return (__.ID(ctx)||document).getElementsByTagName(tag); },
SHOW: function(id){ var N=__.ID(id); N.style.display=''; return N; },
HIDE: function(id){ var N=__.ID(id); N.style.display='none'; return N; }
};
var DEBUG = {
WINDOWS: 0,
SA: function (event)    { var divs = __.TAG('div'); for (var ii=0; ii<divs.length; ++ii) { var DIV = divs[ii]; if ('_SYSTEM_' == DIV.className) __.SHOW(DIV); } var link = event? event.target||event.srcElement: __.ID('SYSTEM_BUTTON'); link.onclick=DEBUG.HA; link.innerHTML = link.innerHTML.replace(/SHOW/, 'HIDE'); link.blur(); },
HA: function (event)    { var divs = __.TAG('div'); for (var ii=0; ii<divs.length; ++ii) { var DIV = divs[ii]; if ('_SYSTEM_' == DIV.className) __.HIDE(DIV); } var link = (event.target||event.srcElement); link.onclick=DEBUG.SA; link.innerHTML = link.innerHTML.replace(/HIDE/, 'SHOW'); link.blur(); },
ADD: function (id,hide) { this.WINDOWS++; this.REFRESH(); if (hide) __.HIDE(id); },
REFRESH: function ()    { var C = __.ID('SYSTEM_COUNTER'); if (this.WINDOWS) C.innerHTML = '('+this.WINDOWS+')'; else __.HIDE(C.parentNode); },
RM: function (link)     { __.RM(link.parentNode); this.WINDOWS--; this.REFRESH(); return false; }
};
</script>
<a href="#" class="_SYSTEM_BUTTON_" id="SYSTEM_BUTTON" onclick="DEBUG.HA(event);return false">HIDE DEBUG <span id="SYSTEM_COUNTER"></span></a>

HTML;
	}

	if (!is_array($contents)) $contents = array($contents);
	
	$trace = array_reverse(format_trace($trace));
	$place = "<b>{$trace[0]['file']}</b>, line <b>{$trace[0]['line']}</b>";

	$places = array();
	foreach ($trace as $t) $places[] = $t['place'];
	$places = join(' &raquo; ', $places);
	
	$rnd = 'debug_'.md5(microtime());

	$vars = array();
	foreach ($contents as $c) $vars[] = "<pre>\n".var_export($c, true)."</pre>\n";
	
	$OUT .= HTML()->
	DIV_('', array('class'=>'_SYSTEM_', 'id'=>$rnd))->
		A('&times;', array('href'=>'#','onmousedown'=>'return DEBUG.RM(event.target||event.src)'))->
		H1_($title)->SMALL(' at '.$place)->_H1()->
		UL($vars, array('class'=>'Vars'))->
		P("<strong>Via:</strong> $places", array('class'=>'Trace'))->
	_DIV()->
	HTML();

	$hide = DEBUG?'false':'true';
	$OUT.="<script type=\"text/javascript\"><!--\nDEBUG.ADD('$rnd',$hide);// --></script>";

	return $OUT;
}

/**
 * Outputs a system message box with specified variables.
 * Accepts any number of parameters.
 *
 * @param mixed $var
 * @return string HTML
 */
function debug ($var) {
	$trace = debug_backtrace();
	$vars  = func_get_args();
	print system_message("Debug", $vars, $trace);
	return true;
}

/**
 * Returns a string representation of a variable
 * 
 * @param  mixed  $var   Variable or object to be stringified
 * @param  bool   $html  Whether to prettify output with HTML and CSS
 * @return string        String representation of input variable or object
 */
function to_string ($var, $html=false) {
	$format = $html? '<em>%s</em>': '%s';
	switch (strtoupper(gettype($var))) {
		case 'ARRAY':   return array_to_string($var, $html);
		case 'BOOLEAN': return sprintf($format, $var? '(TRUE)': '(FALSE)');
		case 'NULL':    return sprintf($format, "(NULL)");
		case 'INTEGER': return sprintf('%d', $var);
		case 'DOUBLE':  return str_replace('.', sprintf($format, "."), print_r($var, true));
		case 'STRING':  return sprintf($format, '"').$var.sprintf($format, '"');
		default:        return sprintf($format, ucfirst(gettype($var))).' '.print_r($var, true);
	}

	return false;
}

/**
 * Returns a string representation of an array
 * 
 * @param  array  $array  Array to be stringified
 * @param  bool   $html   Whether to prettify output with HTML and CSS
 * @return string         String representation of input array
 */
function array_to_string ($array, $html=false) {
	$format = $html? '<em>%s</em>': '%s';
	$s1 = $html? "&nbsp; &nbsp;": '';
	$s2 = $html? "&nbsp;&nbsp;&nbsp;\n": ' ';
	
	$OUT = array();
	$MAX = array_reduce(array_map('strlen', array_keys($array)), 'max');

	foreach ($array as $key=>$val) {
		$SPACER = str_repeat('&nbsp;', max($MAX-strlen($key), 0));
		$OUT[] = to_string($key, $html).$SPACER.sprintf($format, ' = ').str_replace("\n", $s2, to_string($val, $html));
	}
	return sprintf($format, "[$s2").join(",$s2", $OUT).sprintf($format, "$s1]");
}

?>