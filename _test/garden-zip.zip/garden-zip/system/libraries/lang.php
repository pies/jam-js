<?


/** Check if a path is a readable file */
function is_readable_file ($path) {
	return is_readable($path) && is_file($path);
}

/** Remove magic quotes from request data */
static function handle_magic_quotes () {
	if (get_magic_quotes_gpc()) {
		$stripslashes = Lang::func('$string', 'return stripslashes($string);');
		$_POST   = Enum::map_deep($_POST, $stripslashes);
		$_GET    = Enum::map_deep($_GET, $stripslashes);
		$_COOKIE = Enum::map_deep($_COOKIE, $stripslashes);
	}
}

?>