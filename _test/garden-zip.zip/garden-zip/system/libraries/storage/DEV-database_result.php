<?php

/**
 * Database: Result
 * 
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @package Storage
 * @subpackage Database
 * @version $Revision: $
 * @license Public Domain (see system/licence.txt)
 */
class DatabaseResult extends PDOStatement {

	function __get($index) {
	}

	function __set($index) {
	}

}

?>