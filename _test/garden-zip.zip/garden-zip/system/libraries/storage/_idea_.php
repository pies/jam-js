<?php
/**
 * Name
 * --------------------------------------------------------------------------
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @package Package
 * @version $Revision: $
 * @license Public Domain (see system/licence.txt)
*/



abstract class Stored {
	
	public function __construct(){
		
	}
	
	public function getName() {
		return $this->_name? $this->_name: str(get_class($this))->camelize();
	}
	
}



interface StoredItem {
	protected function _save();
	protected function _read();
	protected function _remove();
}



abstract class Item {
	
	protected
		$id         = array('NumberProp', 'auto', 'serial'),
		$created    = array('DateProp',   'auto', 'created'),
		$modified   = array('DateProp',   'auto', 'modified'),
		$_name      = false;

	private 
		$_hasOne    = array(),
		$_hasMany   = array(),
		$_hasOwner  = array();

	public function __construct($id=false) {
		$this->id = $id;
	}
		
	public function __get() {}
	public function __set() {}
	
}

abstract class DatabaseItem extends Item implements Stored {};

?>