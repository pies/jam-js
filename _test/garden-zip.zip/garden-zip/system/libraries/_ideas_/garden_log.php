<?php

class GardenLog
{
	function error (Error $error, $toScreen=false) {
		self::toFile($error);
		self::toScreen($error);
		self::toDatabase($error);
	}
	
	function toFile(Error $error) {
		extract($error->toArray());
		$path = DIR_ROOT.'/logs/'.date('y-m-d').'_'.ucfirst(strtolower($signal)).'.log';
		$msg  = date('H:i:s')." {$component} {$signal} at {$place} - {$title}\n";
		return ($log = fopen($path, 'a+')) && 
		       fwrite($log, $msg) && 
		       fclose($log);
	}

	static function toScreen(Error $error) {
		extract($error->toArray());
		$frmt  = formatter('<li>%s <em>in</em> %s</li>');
		$msg   = date('H:i:s')." {$component} {$signal} at {$place} - {$title}\n";
		$trace = join(array_map($frmt, format_trace($error->getTrace()) ));
		return 
<<<HTML
<style type="text/css">

.Debug { font-family:Calibri,Arial,sans-serif; border:1px solid #D86; padding:0 0 .7em .5em; margin:.5em 0 }
.Debug PRE { font-family:Consolas,Courier,monospace; margin:0; }
.Debug SMALL { color:#777; }
.Debug H1 { font-size:1.3em; margin:5px 0 0 0; color: #F75; }
.Debug H1 SMALL { font-size:.8em; color: #777; }
.Debug H1 SMALL STRONG { color: #000; }
.Debug H2 { font-size:1em; background-color:#EE9; margin:.5em 0 0 -8px; padding:.3em 10px; }
.Debug H3 { font-size:1em; margin:0 -8px; padding:0 10px .2em 10px; }
.Debug H4 { font-size:.9em; margin:7px 0 10px 1px; float:left; }
.Debug UL { font-size:1em; margin:5px 5px 0 0; padding-left:1.7em; list-style:none; }

</style>
<div class="Debug">
<h1>Unhandled exception
<small>at $place</small></h1>
<h2>$msg</h2>
<h4>Via:</h4>
<ul>$trace</ul>
</div>
HTML;
	}

	function toDatabase(Error $error) {
		$data = $error->toArray();
		$sql = 'INSERT INTO messages ('.join(',',array_keys($data)).') VALUES ('.join(','.$data).')';
		return ($db = sqlite_open(DIR_ROOT.'/data/system.db')) &&
		       sqlite_query($db, $sql) &&
		       sqlite_close($db);
	}
}

?>