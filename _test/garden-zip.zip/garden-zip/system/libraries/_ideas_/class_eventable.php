<?php
/**
 * Name
 * --------------------------------------------------------------------------
 * @author Michal Tatarynowicz <tatarynowicz@gmail.com>
 * @copyright 2006 Michal Tatarynowicz
 * @package Package
 * @version $Revision: $
 * @license Public Domain (see system/licence.txt)
*/

abstract class Eventable {
	
	private $_events = array();

	public function __call($name, $params) {
		
		if (in_array($name, array('before','after'))) {
			list ($item, $callback) = $params;
			$this->addEvent($name, $item, $callback);
		}
		
	}
	
	public function onEvent($type, $name, $params) {
		$events = $this->_events[$type][$name] OR array();
		foreach ($events as $callback) call($callback, $params);
	}
	
	public function addEvent($type, $name, $callback) {
		return @$this->_events[$type][$name][] = $callback;
	}
	
}

?>